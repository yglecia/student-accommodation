function toggleForm() {
    var loginForm = document.getElementById("loginForm");
    var registerForm = document.getElementById("registerForm");

    if (loginForm.style.display === "none") {
        loginForm.style.display = "block";
        registerForm.style.display = "none";
    } else {
        loginForm.style.display = "none";
        registerForm.style.display = "block";
    }
}

document.getElementById("login").addEventListener("submit", function(event) {
    event.preventDefault();
    var email = document.getElementById("loginEmail").value;
    var password = document.getElementById("loginPassword").value;
    // Add login functionality here
});

document.getElementById("register").addEventListener("submit", function(event) {
    event.preventDefault();
    var email = document.getElementById("registerEmail").value;
    var phone = document.getElementById("registerPhone").value;
    var password = document.getElementById("registerPassword").value;
    var location = document.getElementById("registerLocation").value;
    var accommodation = document.getElementById("registerAccommodation").value;
    var budget = document.getElementById("registerBudget").value;
    var details = document.getElementById("registerDetails").value;
    // Add registration functionality here
});
